'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import supabase from '@/utils/supabase';

type Props = { children?: React.ReactNode };

export default function RequireAuth({ children }: Props) {
  const router = useRouter();

  useEffect(() => {
    let mounted = true;
    supabase.auth.getUser().then(({ data }) => {
      if (!mounted) return;
      if (!data.user) router.replace('/signin');
    });
    return () => {
      mounted = false;
    };
  }, [router]);

  // We render children so layout doesn’t jump; redirect will happen if not signed in.
  return <>{children}</>;
}