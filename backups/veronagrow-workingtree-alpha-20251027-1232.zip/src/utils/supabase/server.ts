// Minimal bridge to the unified server helper.
// Keeps old imports working without duplicating logic.

import createServerSupabase from '@/utils/supabase-server';

export default createServerSupabase;