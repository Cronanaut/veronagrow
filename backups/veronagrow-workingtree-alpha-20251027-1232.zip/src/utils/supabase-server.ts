// Stable alias so imports like '@/utils/supabase-server' always work.
export { default } from './supabase/supabase-server';